// lib/modes/basra/presentation/widgets/basra_player_info.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:estimation/modes/basra/domain/models/basra_game_state.dart';
import 'package:estimation/theme/app_theme.dart';
import 'package:estimation/widgets/hud/glass_player_card.dart';
import 'package:estimation/widgets/hud/player_avatar_ring.dart';

class BasraPlayerInfoWidget extends StatelessWidget {
  final BasraPlayer player;
  final bool isCurrentTurn;
  final bool isMe;
  final bool compact;

  const BasraPlayerInfoWidget({
    super.key,
    required this.player,
    this.isCurrentTurn = false,
    this.isMe = false,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final accent = isCurrentTurn ? AppTheme.gold : AppTheme.steelBlue;
    return RepaintBoundary(
      child: GlassPlayerCard(
        isCurrentTurn: isCurrentTurn,
        accentColor: accent,
        compact: compact,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            PlayerAvatarRing(
              photoData: null,
              playerName: player.name,
              size: compact ? 26 : 40,
              ringColor: accent,
              isCurrentTurn: isCurrentTurn,
              compact: compact,
            ),
            const SizedBox(width: 8),
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isMe ? 'أنا' : player.name,
                  style: GoogleFonts.cairo(
                    color: AppTheme.cream,
                    fontSize: compact ? 10 : 12.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(
                  '${player.totalScore} • جولة ${player.roundScore} • باصرة ${player.basraCount} • ${player.capturedCards.length} ورقة',
                  style: GoogleFonts.cairo(
                    color: AppTheme.gold,
                    fontSize: compact ? 9 : 11,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
